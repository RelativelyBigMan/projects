document.addEventListener("DOMContentLoaded", () => {
    const generatePassword = document.getElementById("Generate");

    if (generatePassword) {
        generatePassword.addEventListener("click", () => {
            window.location.assign("index.html");
        });
    } else {
        console.error("Element with id 'Generate' not found.");
    }
});

document.addEventListener("DOMContentLoaded", () => {
    
    let passwordWrappers = document.getElementById("passwords");
    if (!passwordWrappers) {
        console.error("Element with id 'passwords' not found.");
        return;
    }
    
    let passwordsParam = new URLSearchParams(window.location.search).get('passwords');
    if (!passwordsParam) {
        console.error("No 'passwords' parameter found in URL.");
        return;
    }
    // Adjust slicing/decoding logic based on how the passwords parameter was encoded.
    try {
        
        let passwords = atob(passwordsParam).split(",").slice(1);
        console.log(passwords);

        passwords.forEach(password => {
            passwordWrappers.innerHTML += `<div>${password}</div>`;
        });
    } catch (error) {
        console.error("Error decoding passwords:", error);
    }
});


